# install SAJR
#install.packages("http://storage.bioinf.fbb.msu.ru/~mazin/files/SAJR.tar.gz", repos = NULL, type = "source")

library(SAJR)

grp1="Day 3"
grp2="Day 15"
significance=0.05
ann.gff='novel.gff'

grp1_samples = c("N2_ev_1_day3","N2_ev_2_day3","N2_ev_3_day3","N2_ev_4_day3")
grp2_samples = c("N2_ev_1_day15","N2_ev_2_day15","N2_ev_3_day15","N2_ev_4_day15")
samples=c(grp1_samples,grp2_samples)
cond=factor(c(rep(grp1,length(grp1_samples)),rep(grp2,length(grp2_samples))))
cond=relevel(cond, ref=grp1)
sequenced=factor(c(rep("Jan",2),rep("Feb",2),rep("Jan",2),rep("Feb",2)))
meta = list(cond=cond,sequenced=sequenced)
meta

# load annotation and count data
data = loadSAData(ann.gff=ann.gff,samples)
data<-setSplSiteTypes(data, ann.gff)

# filter low-coverage segments
# Old filtering used in paper but no longer supported by SAJR:
#data.f = filterSegs(data,types=c('ALT','EXN','INT'), positions=c('LAST','INTERNAL','FIRST'), min.e.cov=5, min.i.cov=5, min.nonzero.libs=min(length(grp1_samples),length(grp2_samples)))

# new recommended filtering:
data.f = data[data$seg$type %in% c('ALT','EXN','INT') & data$seg$position %in% c('LAST','INTERNAL','FIRST') & apply(data$i+data$e>=10,1,sum)>=2 & apply(data$ir,1,sd,na.rm=TRUE) > 0,]

# test for significant differences
data.f.glm = fitSAGLM(data.f,formula=terms(x ~ sequenced + cond, keep.order=T),meta,0.05)
data.f.pv = calcSAPvalue(data.f.glm)
data.f$seg[,c("pvalue")]=data.f.pv[,"cond"]
data.f$seg[,c("padj")] = p.adjust(data.f$seg[,c("pvalue")],method='BH')

# calculate group means and log2FC
data.f$seg[,c("psi.grp1")]<-rowMeans(data.f$ir[,1:length(grp1_samples)], na.rm=T)
data.f$seg[,c("psi.grp2")]<-rowMeans(data.f$ir[,(1+length(grp1_samples)):length(c(grp1_samples,grp2_samples))], na.rm=T)
data.f$seg[,c("grp1.sd")]<-apply(data.f$ir[,1:length(grp1_samples)],1,function(x) sd(x, na.rm=T))
data.f$seg[,c("grp2.sd")]<-apply(data.f$ir[,(1+length(grp1_samples)):length(c(grp1_samples,grp2_samples))],1,function(x) sd(x, na.rm=T))
data.f$seg[,c("psi.diff")]<-data.f$seg[,c("psi.grp2")] - data.f$seg[,c("psi.grp1")]
data.f$seg[,c("log2FC")]<-log2((data.f$seg[,c("psi.grp2")]+0.01)/(data.f$seg[,c("psi.grp1")]+0.01)) # add one percent pseudoinclusion to avoid division-by-zero

# read annotation data
novelty<-read.delim("novel_ovelap_known_stringent_novel.tsv", header=F)
novelty<-novelty[!duplicated(novelty[,1]),]
colnames(novelty)=c("segment","Novelty")
rownames(novelty)=novelty$segment

names_from_overlap<-read.delim("novel2known_from_overlap.tsv", header=F)
rownames(names_from_overlap)=names_from_overlap[,1]
colnames(names_from_overlap)=c("sajrSegID","GeneName")
head(names_from_overlap)

names_from_comp<-read.delim("sajr.novel2known.tsv", header=F)
rownames(names_from_comp)=names_from_comp[,1]
colnames(names_from_comp) = c("gene_id","GeneNames","Class")
head(names_from_comp)

# save results
data.res <- data.f
colnames(data.res$ir) <- paste("ir", colnames(data.res$ir), sep = ".")
colnames(data.res$i) <- paste("i", colnames(data.res$i), sep = ".")
colnames(data.res$e) <- paste("e", colnames(data.res$e), sep = ".")
res<-data.res$seg
res<-merge(res, data.res$ir, by="row.names")
rownames(res)=res$Row.names
res<-res[,-1]
res<-merge(res, data.res$i, by="row.names")
rownames(res)=res$Row.names
res<-res[,-1]
res<-merge(res, data.res$e, by="row.names")
rownames(res)=res$Row.names
res<-res[,-1]
res<-merge(res, novelty, by="row.names")
rownames(res)=res$Row.names
res<-res[,-1]
res<-merge(names_from_comp,res, by="gene_id")
rownames(res)=res$segment.x
res<-merge(names_from_overlap,res, by="row.names")
rownames(res)=res$Row.names
res<-res[,-1]

# sort the data according to p-value
res<-res[order(res$pvalue),]
head(res)
write.table(res,file="results.tsv", sep="\t", quote=F, row.names=F)
